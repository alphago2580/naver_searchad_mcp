from .fastmcp_server import build_server, mcp  # re-export
